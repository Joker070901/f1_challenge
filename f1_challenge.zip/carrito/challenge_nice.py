import turtle
import keyboard
from lagrange import *
from math import *

# Car textures!
screen = turtle.Screen()
screen.register_shape("f1_car0.gif")
screen.register_shape("f1_car45.gif")
screen.register_shape("f1_car_90.gif")
screen.register_shape("f1_car135.gif")
screen.register_shape("f1_car225.gif")
screen.register_shape("f1_car270.gif")
screen.register_shape("f1_car315.gif")
screen.register_shape("gover.gif")

screen.register_shape("f1.gif")
screen.register_shape("tec.gif")

cas=int(input("¿Que caso desea ver? ¿1 o 2? "))

# Case validation!

if cas==1:
    grad1x=710
    grad1y=2100
    grad2x=1400
    grad2y=3500
    o1=1
    o2=-1
    incl1=0
    incl2=10
    x0 = 100
    y0 = 2900
    x3 = 2800
    y3 = 2400
    x1 = x0+(x3-x0)/3; 
    y1 = y0-600
    x2 = x3-(x3-x0)/3; 
    y2 = y0+600

    ch=input("¿Desea chocar? (S/N)")
    ch=ch.upper()
    if ch =="S":


        speed1=1.12
        brake=.2
        
        speed2=.8
    else:

        speed1=1.1
        brake=0.2
        speed2=0.8
else:
    grad1x=2350
    grad1y=200
    grad2x=-70
    grad2y=2600
    o1=1
    o2=-1
    incl1=-4
    incl2=6
    x0 = 100
    y0 = 1700
    x3 = 2800
    y3 = 200
    x1 = x0+(x3-x0)/3; 
    y1 = y0+800
    x2 = x3-(x3-x0)/3; 
    y2 = y0-800
    ch=input("¿Desea chocar? (S/N)")
    ch=ch.upper()
    if ch =="S":


        speed1=1.3
        brake=0.2
        speed2=.9
    else:

        speed1=1.1
        brake=0.2
        speed2=0.7
    
# Collision validation!


datos="Punto inicial: ("+str(x0)+","+str(y0)+") Punto final: ("+str(x3)+","+str(y3)+")"


def cubic(x,p1,p2,p3,p4):
    return x*x*x*p1+x*x*p2+x*p3+p4


def gradas(x,y,svx,svy,z,o,inc):
    cuad=(x-svx)/z
    cuady=(y-svy)/z
    painter.penup()
    painter.goto(cuad-o*10,cuady-30)
    painter.pendown()
    painter.goto(cuad-o*50,cuady+10+inc)
    painter.goto(cuad-o*50,cuady+20+inc)
    painter.goto(cuad-o*10,cuady-20)
    painter.goto(cuad-o*10,cuady-30)
    painter.penup()


def drawTrack(startX,startY,graphingFunction, p1,p2,p3,p4,startViewX,startViewY,z):


    for i in range(startX, startY):
            x = i
            y = graphingFunction(x,p1,p2,p3,p4)
            painter.goto((i-startViewX)/z,(y-startViewY)/z)
            painter.pendown()
    gradas(grad1x,grad1y,startViewX,startViewY,z,o1,incl1)
    gradas(grad2x,grad2y,startViewX,startViewY,z,o2,incl2)

def squareDerivativeOnPoint(x,a,b,c):
    return a*x*x + b*x + c

def squareSecondDerivativeOnPoint(x,a,b,c):
    return a*x + b 

def vecMagnitude(x,y):
    return sqrt(x*x + y*y)

def maxVelocity(x):
    global  ma
    global  mb
    global  mc
    u=squareDerivativeOnPoint(x,ma,mb,mc)
    uu=squareSecondDerivativeOnPoint(x,ma,mb,mc)
    radiusc = ((1+ u**2)**(3/2)) / abs(uu)
    friction = 0.6
    return sqrt(friction * 9.81 * radiusc)

def arc(x0,x3,p1,p2,p3,p4):
    d=0
    for x11 in range (int(x0),int(x3)):
        y11=cubic(x11,p1,p2,p3,p4)
        y22=cubic(x11+1,p1,p2,p3,p4)
        d=d+trianglesDistance(x11+1,x11,y22,y11)
    return d

def simulate(x0,y0,x1,y1,x2,y2,x3,y3, startX, startY, graphingFunction,startViewX, startViewY, gDelay,z):

    
    turtle.Screen().delay(100)
    turtle.screensize(900,900)
        
    p1,p2,p3,p4 = lagrange(x0,y0,x1,y1,x2,y2,x3,y3)
    global ma
    global mb
    global mc
    # Derivative!
    ma,mb,mc = findPossibleMaxMin(p1,p2,p3)
    print(p1 , "," , p2, ",",p3 , " " , p4)
    # Critic points!
    minMax1, minMax2 = findMaxMin(ma,mb,mc)

    # Deciding whether is Max or Min for first point x1
    if( minMax1 == minMax2 == "0" ):
        print("cannot be done")
    elif( isMaximum(ma,mb,x1) ):
        print("max 1" , minMax1)
        minMaxY1 = cubic(minMax1, p1,p2,p3,p4)
        
    else:
        print("min 1" , minMax1)
        minMaxY1 = cubic(minMax1, p1,p2,p3,p4)
    print("y) 1" , minMaxY1)
        
     # Deciding whether is Max or Min for first point x2    
    if( minMax1 == minMax2 == "0" ):
        print("cannot be done")
    elif( isMaximum(ma,mb,x2) ):
        print("max 2" , minMax2)
        minMaxY2 = cubic(minMax2, p1,p2,p3,p4)
    else:
        print("min 2" , minMax2)
        minMaxY2 = cubic(minMax2, p1,p2,p3,p4)
    print("y) 2" , minMaxY2)

    curveOut = False
    speed = 0.0
    actualX = startX
    actualY = startY
    # Tracer = 0 then it graphs all at once
    turtle.tracer(0)
    doCrash = False
    while(not curveOut and not doCrash):

        # Pause Loop!
        if keyboard.is_pressed('p'):
            for x in range(1,1000000):
                print("") 
                if keyboard.is_pressed('c'):
                    break
        
        painter.penup()
        turtle.Screen().delay(100)
        # Eliminate innecesary lines
        painter.clear()
        drawTrack(startX,startY, graphingFunction, p1,p2,p3,p4,startViewX,startViewY,z)      
        painter.penup()
        actualY = graphingFunction(actualX,p1,p2,p3,p4)
        prevY = graphingFunction(actualX-speed,p1,p2,p3,p4)
        painter.goto((actualX-startViewX)/z,(actualY-startViewY)/z)

        # logo is turtle object

        logo.penup()
        logo.goto(300,200)
        logo.shape("f1.gif")
        logoT.penup()
        logoT.goto(-280,200)
        logoT.shape("tec.gif")
        painter.pendown()
        # Print position
        # print( ((actualX-startViewX)/z),((actualY-startViewY)/z) )
        turtle.Screen().update()

        # check if speed can go up
        if( speed  == 0):
            speed = 2
        else:
            # Calculate actual and previous derivatives
            # x is the prevX +- speed
            prevX = actualX - speed # one is a very small value for the total scale
            prevSpeedY = squareDerivativeOnPoint(prevX, ma,mb,mc)
            actualSpeedY = squareDerivativeOnPoint(actualX, ma,mb,mc)
            magA = vecMagnitude(1,prevSpeedY) # if f(s) = x then f'(s) = 1
            magB = vecMagnitude(1,actualSpeedY) # also if derivative is slope, then y/1 = y/x then x=1
            axbxayby = (1 + prevSpeedY*actualSpeedY)



            # Calculate ang between derivatives
            ang = 0
            if abs( axbxayby - magA*magB )< 0.00001:
                ang = 0
            else:
                ang = acos(axbxayby/(magA*magB))
            
            m = squareDerivativeOnPoint(actualX,ma,mb,mc)

            # Car graphics!
            if magA != 0:
                if m >= 0:
                    angh = acos(1 / magA)
                    angh = angh*180/pi
                else:
                    angh = acos(1 / magA)
                    angh = angh*180/pi
                    angh = angh * -1
            
            if angh >= -5 and angh < 40:
                painter.shape("f1_car0.gif")
            if angh > 40:
                painter.shape("f1_car45.gif")
            if angh < -15 and angh > -60:
                painter.shape("f1_car315.gif")



            vx = actualX-prevX
            vy = actualY-prevY
            velocityVector = vecMagnitude(vx,vy)
         

            
            painter.penup()
            ecuacion = "Equation: "+str(p1)+" x^3 +"+str(p2)+" x^2 "+str(p3)+" x+ "+str(p4)
            painter.goto(-350,70)
            painter.write(ecuacion)
            painter.goto(-350,90)
            painter.write(datos)
            painter.penup()
            painter.showturtle()
            #print("Speed calculated as vector (" , kmPerHour ,")" , speed  )
            #print(pi)

            ang = ang*180/pi
            #print(ang)
            if( abs(ang) < 5):
                if velocityVector>105:
                    speed=speed
                    velocityVector=105
                    ac=1
                else:
                    speed = speed*speed1 # speed capability
                    ac = speed1
            elif( abs(ang) > 45):
                speed = speed*brake # brake capability
                ac = brake 
                
            elif( abs(ang) > 5):
                if velocityVector>105:
                    speed=speed
                    kmPerHour = "Speed:" + str((velocityVector*3.6))
                    ac = 1
                else:
                    speed = speed*speed2 # speed capability
                    ac = speed2


           
               
            painter.penup()
            painter.goto(200,30)
            painter.write("Angle: " + str(abs(angh)) + "°")
            painter.goto(200,10)
            painter.write("Actual Speed: " + str(velocityVector*3.6) + " [km/hr]")
            painter.goto(200,-30)
            aceler = squareSecondDerivativeOnPoint(actualX,ma,mb,mc)
            painter.write("Break/Acceleration: " + str(ac))
            leng = arc(x0,x3,p1,p2,p3,p4)
            painter.goto(200,-50)
            painter.write("Circuit Lenght: " + str(leng)+ " [m]")
            

            #speed = min(84,speed)
    
        if (speed >= maxVelocity(actualX)):
            curveOut = True
            doCrash = True
            painter.goto((actualX-startViewX)/z,(actualY-startViewY)/z)
            turtle.Screen().update()
        else:
            actualX = actualX + speed
        if( actualX > x3 ):
            curveOut = True

    painter.ht()
    painter.pendown()
    

    if( doCrash ):
        
        turtle.tracer(0)
        # get y=m(x-x1)+y1
        lastPointX = actualX
        lastPointY = actualY
        m = squareDerivativeOnPoint(lastPointX,ma,mb,mc)

        painter.penup()
        painter.goto(200,-10)
        painter.write("Max Speed: " + str(maxVelocity(lastPointX)*3.6) + " [km/hr]")
        gover.shape("gover.gif")
        gover.penup()
        gover.goto(300,-120)

        
        for i in range(0,100):
            lastPointX = lastPointX+5
            lastPointY = lastPointY+5*m
            dest_car.penup()

            # Car graphics!
            if magA != 0:
                if m >= 0:
                    angh = acos(1 / magA)
                    angh = angh*180/pi
                else:
                    angh = acos(1 / magA)
                    angh = angh*180/pi
                    angh = angh * -1
            
            if angh >= -5 and angh < 40:
                dest_car.shape("f1_car0.gif")
            if angh > 40:
                dest_car.shape("f1_car45.gif")
            if angh < -15 and angh > -60:
                dest_car.shape("f1_car315.gif")

            
            dest_car.goto((lastPointX-startViewX)/z,(lastPointY-startViewY)/z)
            painter.goto((lastPointX-startViewX)/z,(lastPointY-startViewY)/z)
            painter.color('blue')
            painter.dot(5)
            # Clear past graphication and do the next
            turtle.Screen().update()


    # Draw circles!
    turtle.tracer(0)
    painter.penup()
    if cas == 1:
        painter.goto((minMax1-startViewX)/z,(minMaxY1-startViewY)/z)
        painter.pendown()
        painter.circle(100/z)
        painter.penup()
        painter.goto((minMax2-startViewX)/z,(minMaxY2-startViewY-200)/z)
        painter.pendown()
        painter.circle(100/z)
        turtle.Screen().update()
        turtle.Terminator()
    elif cas == 2:
        painter.goto((minMax1-startViewX)/z,(minMaxY1-startViewY)/z)
        painter.pendown()
        painter.circle(100/z)
        painter.penup()
        painter.goto((minMax2-startViewX)/z,((minMaxY2-startViewY)/z)-20)
        painter.pendown()
        painter.circle(100/z)
        turtle.Screen().update()
        turtle.Terminator()

ma = 0
mb = 0
mc = 0
offsetX = 1000
offsetY = 1000


#print(x0,",",y0)
#print(x1,",",y1)
#print(x2,",",y2)
#print(x3,",",y3)


painter = turtle.Turtle()
logo = turtle.Turtle()
logoT = turtle.Turtle()
gover = turtle.Turtle()
dest_car = turtle.Turtle()
turtle.tracer(0)
painter.pendown()
simulate(x0,y0,x1,y1,x2,y2,x3,y3,300,2800, cubic,x0+offsetX,y0+offsetY,1000, 10 )
painter.penup()


input()


